export interface Enclosure {
	"id": string;
    "name": string;
    "ip": string;
    "status": boolean;
    "lastUpdated": string;
    "sbc": SBC;
    "sdr": SDR;
    "rfChains": rfChain[];
}

export interface SBC {
	"type": string;
	"vendorSerial": string; 
	"ip": string;
	"simNumber": number;
	"memorySize": number;
	"storageSize": number;
}
export interface SDR {
	"type": string;
	"vendorSerial": string; 
	"ip": string;
	"BTS": Array<localBTS>;
	// "BTSport1": string;
	// "BTSport2": string;
	"port": string;
	"protocols": Array<object>; 
	"swVersion": string;
	"build": string;
}

export interface rfChain {
	"amp": Amplifier;
	"freqBands": Array<freqBand>; 
	"type": string;
}
export interface freqBand {
	"gain": string,
	"loss": string,
	"band": string
}

export interface Amplifier {
	"ip": string, 
	"make": string,
	"model": string,
	"mfcSerial": string,
	"picSixSerial": string 
}

export interface localBTS {
	"ip": string,
	"port": string
}

export function createLocalBTS(ip?: string, port?: string){
	return {
		ip: ip,
		port: port
	}
}

export function createEnclosure(id?: string, name?: string, ip?: string,
    status?: boolean, lastUpdated?: string, sbc?: SBC, sdr?: SDR,
    rfChains?: rfChain[]){
	return {
		id: id,
		name: name,
	    ip: ip,
	    status: status,
	    lastUpdated: lastUpdated,
	    sbc: createSBC(),
	    sdr: createSDR(),
	    rfChains: [createRfChain()] 
	}
}

export function createSBC(type?: string,vendorSerial?: string, ip?: string,
	simNumber?: number,memorySize?: number,storageSize?: number) {
	return {
		type: type,
		vendorSerial: vendorSerial,
		ip: ip,
		simNumber: simNumber,
		memorySize: memorySize,
		storageSize: storageSize
	}
}

export function createSDR(type?: string, vendorSerial?: string, 
	ip?: string, BTS?: localBTS, BTSport1?: string, BTSport2?: string, port?: string,
	protocols?: object, swVersion?: string, build?: string){
	return {
		type: type, 
		vendorSerial: vendorSerial, 
		ip: ip, 
		BTS: [createLocalBTS()],
		// BTSport1: BTSport1, 
		// BTSport2: BTSport2, 
		port: port,
		protocols: {"twoG": false, "threeG": false, "fourG": false},
		swVersion: swVersion,
		build: build	
	}
}

export function createRfChain(type?: string, freqBands?:Array<freqBand>, 
	amp?: Amplifier){
	return {
		type: type || 'Shared',
		freqBands: [createFreqBand()], 
		
		amp: createAmplifier()
	}
}
export function createFreqBand(gain?: string, loss?: string, band?: string){
	return {
		gain: gain,
		loss: loss,
		band: band
	}
}
export function createAmplifier(ip?: string, make?: string, model?: string, 
	mfcSerial?: string, picSixSerial?: string){
	return {
		ip: ip, 
		make: make,
		model: model,
		mfcSerial: mfcSerial,
		picSixSerial: picSixSerial 
	}
}


