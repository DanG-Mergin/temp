import { TestBed, inject } from '@angular/core/testing';

import { BTSService } from './bts.service';

describe('BTSService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BTSService]
    });
  });

  it('should be created', inject([BTSService], (service: BTSService) => {
    expect(service).toBeTruthy();
  }));
});
