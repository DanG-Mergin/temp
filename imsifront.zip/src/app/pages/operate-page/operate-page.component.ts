import { Component, OnInit } from '@angular/core';
import { BTS } from '../../services/BTS';
import { BTSService } from '../../services/bts.service';
import { MessageService } from '../../services/message.service';

// import { EmulateDetailComponent } from '../../pages/emulate/emulate-detail/emulate-detail.component';

@Component({
  selector: 'app-operate-page',
  templateUrl: './operate-page.component.html',
  styleUrls: ['./operate-page.component.scss']
})
export class OperatePageComponent implements OnInit {
	btss: BTS[];
	message:string;

	constructor(private scanService: BTSService, private data: MessageService) { }

	ngOnInit() {
		this.scanService.getAllSelectedBTS().subscribe(btss => this.btss = btss);
	    this.data.currentMessage.subscribe(message => this.message = message);
	}

	newMessage() {
		this.data.changeMessage("Hello from Emulate");
	}
}
