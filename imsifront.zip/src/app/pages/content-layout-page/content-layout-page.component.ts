import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-layout-page',
  templateUrl: './content-layout-page.component.html',
  styleUrls: ['./content-layout-page.component.scss']
})
export class ContentLayoutPageComponent {
}
