import { Component, OnInit } from '@angular/core';

import { TargetsListComponent } from './targets-list/targets-list.component';

@Component({
  selector: 'app-targets-page',
  templateUrl: './targets-page.component.html',
  styleUrls: ['./targets-page.component.scss']
})
export class TargetsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
