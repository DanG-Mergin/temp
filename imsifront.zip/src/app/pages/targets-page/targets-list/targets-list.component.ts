import { Component, OnInit } from '@angular/core';

import { BTS } from '../../../services/BTS';
import { BTSService } from '../../../services/bts.service';

@Component({
  selector: 'app-targets-list',
  templateUrl: './targets-list.component.html',
  styleUrls: ['./targets-list.component.scss']
})
export class TargetsListComponent implements OnInit {
	rows: BTS[];
	selected = [];

	constructor(private scanService: BTSService) { }

	ngOnInit() {
		this.rows = this.rows;
		this.scanService.getAllSelectedBTS().subscribe(selected => this.selected = selected);
		this.scanService.getBTS().subscribe(bts => this.rows = bts);
	}

	getBTS() {
		this.scanService.getBTS().subscribe(bts => this.rows = bts);
	}

	onSelect({ selected }) {
		console.log('Select Event', selected, this.selected);

		this.selected.splice(0, this.selected.length);
		this.selected.push(...selected);

		this.scanService.setSelectedBTS(this.selected);
		
	}

	onActivate(event) {
		console.log('Activate Event', event);
	}

}
