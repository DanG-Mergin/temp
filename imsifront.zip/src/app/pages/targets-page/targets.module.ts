import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from '@angular/forms';

import { TargetsPageRoutingModule } from "./targets-page-routing.module";
import { TargetsListComponent } from './targets-list/targets-list.component';
import { TargetsPageComponent } from './targets-page.component';

@NgModule({
  imports: [
    CommonModule,
    TargetsPageRoutingModule
  ],
  declarations: [TargetsListComponent, TargetsPageComponent]
})
export class TargetsModule { }



