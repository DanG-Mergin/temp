import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from '@angular/forms';


import { EmulateComponent } from './emulate.component';
import { EmulateDetailComponent } from './emulate-detail/emulate-detail.component';


@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		NgbModule,
		NgxDatatableModule,

	],
	declarations: [
		EmulateComponent,
		EmulateDetailComponent
	],
	exports: [
		EmulateComponent,
		EmulateDetailComponent
	],
})
export class EmulateModule { }



