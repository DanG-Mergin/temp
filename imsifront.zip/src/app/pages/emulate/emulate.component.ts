import { Component, OnInit } from '@angular/core';
import { BTS } from '../../services/BTS';
import { BTSService } from '../../services/bts.service';
import { MessageService } from '../../services/message.service';

@Component({
  selector: 'app-emulate',
  templateUrl: './emulate.component.html',
  styleUrls: ['./emulate.component.scss']
})
export class EmulateComponent implements OnInit {
  btss: BTS[];
  // isCollapsed: boolean = true;
  message:string;

  constructor(private scanService: BTSService, private data: MessageService) { }

  ngOnInit() {
    this.scanService.getAllSelectedBTS().subscribe(btss => this.btss = btss);
    this.data.currentMessage.subscribe(message => this.message = message);
    console.log(this.btss);
  }
  // toggleExpand(event) {
  //   console.log('HELLO');
  //   console.log(event);
  //   this.isCollapsed = event;
  // }
  newMessage() {
    this.data.changeMessage("Hello from Emulate");
  }
}
