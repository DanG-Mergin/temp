import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BTS } from '../../../services/BTS';

@Component({
  selector: 'app-emulate-detail',
  templateUrl: './emulate-detail.component.html',
  styleUrls: ['./emulate-detail.component.scss']
})
export class EmulateDetailComponent implements OnInit {
	@Input() bts: BTS; 
	// @Input() isCollapsed: boolean;

	@Output() toggleCollapse: EventEmitter<boolean> =  new EventEmitter<boolean>();

	isCollapsed: boolean = true;

	constructor() { }

	ngOnInit() {
		this.bts = this.bts;
	}
	toggleExpand() {
		console.log('toggle expand');
		this.isCollapsed = !this.isCollapsed;
		this.toggleCollapse.emit(this.isCollapsed);
	}
}
