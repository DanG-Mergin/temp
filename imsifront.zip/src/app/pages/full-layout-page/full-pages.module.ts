import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

import { ArchwizardModule } from 'angular-archwizard';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from '@angular/forms';
import { FullPagesRoutingModule } from "./full-pages-routing.module";

import { FullLayoutPageComponent } from './full-layout-page.component';

import { ScanComponent } from './scan/scan-list/scan-list.component';
import { ScanSelectComponent } from './scan/scan-select/scan-select.component';
import { EmulateModule } from '../emulate/emulate.module';
// import { EmulateComponent } from '../emulate/emulate.component';
// import { EmulateDetailComponent } from '../emulate/emulate-detail/emulate-detail.component';

// import { GoogleMapComponent } from './maps/google-map/google-map.component';
// import { FullScreenMapComponent } from './maps/full-screen-map/full-screen-map.component'

import { MapsModule } from './maps/maps.module';

@NgModule({
    imports: [
        ArchwizardModule,
        CommonModule,
        EmulateModule, 
        FullPagesRoutingModule,
        NgxDatatableModule,
        FormsModule,
        MapsModule,
        NgbModule.forRoot()
    ],
    declarations: [       
        FullLayoutPageComponent,
        ScanComponent,
        // EmulateComponent,
        // EmulateDetailComponent,
        ScanSelectComponent
    ]
})
export class FullPagesModule { }
