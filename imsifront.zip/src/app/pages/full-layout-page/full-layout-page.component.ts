import { Component } from '@angular/core';
import { MessageService } from '../../services/message.service';
import { BTS } from '../../services/BTS';
import { EmulateComponent } from '../emulate/emulate.component';
import { EmulateDetailComponent } from '../emulate/emulate-detail/emulate-detail.component';


@Component({
  selector: 'app-full-layout-page',
  templateUrl: './full-layout-page.component.html',
  styleUrls: ['./full-layout-page.component.scss']
})
export class FullLayoutPageComponent {
	message:string;
	selectedBTS: BTS[];
	listActive: boolean = true;
	mapActive: boolean = false;

	constructor(private data: MessageService) {}

	ngOnInit() {
		this.data.currentMessage.subscribe(message => this.message = message)
	}

	// runScan = function(){
	// 	this.scanActive = !this.scanActive;
	// }	
}
