import { Component, OnInit } from '@angular/core';

import { BTS } from '../../../../services/BTS';
import { BTSService } from '../../../../services/bts.service';
import { MessageService } from '../../../../services/message.service';


@Component({
	selector: 'app-scan-list-component',
	templateUrl: './scan-list.component.html',
	styleUrls: ['./scan-list.component.scss']
})
export class ScanComponent implements OnInit {
	rows: BTS[];
	selected = [];
	message: string;

	constructor(private scanService: BTSService, private data: MessageService) { 
		//console.log(this.getBTS());
	}

	ngOnInit() {
		this.rows = this.rows;
		this.data.currentMessage.subscribe(message => this.message = message);
		this.scanService.getAllSelectedBTS().subscribe(selected => this.selected = selected);
		this.scanService.getBTS().subscribe(bts => this.rows = bts);
	}
	
	newMessage() {
		this.data.changeMessage("Hello from Scan");
	}

	getBTS() {
		this.scanService.getBTS().subscribe(bts => this.rows = bts);
	}

	onSelect({ selected }) {
		console.log('Select Event', selected, this.selected);

		this.selected.splice(0, this.selected.length);
		this.selected.push(...selected);

		this.scanService.setSelectedBTS(this.selected);
		
	}

	onActivate(event) {
		console.log('Activate Event', event);
	}

}
