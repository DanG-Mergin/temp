import { Component, OnInit } from '@angular/core';

import { Enclosure } from '../../../../services/enclosure';
import { EnclosureService } from '../../../../services/enclosure.service';

@Component({
	selector: 'app-scan-select',
	templateUrl: './scan-select.component.html',
	styleUrls: ['./scan-select.component.scss']
})
export class ScanSelectComponent implements OnInit {
	selectAllGs = {
		all: true,
		twoG: true,
		threeG: true,
		fourG: true
	};
	enclosures: Enclosure[];
	localBTS = [];


	constructor(private enclosureService: EnclosureService) { }

	ngOnInit() {
		this.getEnclosures();
	}
	getEnclosures() {

		this.enclosureService.getEnclosures().subscribe(enclosures => {
			this.localBTS = this.mapLocalBTS(enclosures);
		});
		// this.enclosureService.getEnclosures().subscribe(enclosures => this.enclosures = enclosures);
		//this.enclosureService.getEnclosures().subscribe(function(enclosures) {console.log(enclosures)});
	}
	mapLocalBTS(enclosures) {
		let localBTS = [];
		for(let i=0; i<enclosures.length; i++){
			if(enclosures[i]['sdr'] && enclosures[i]['sdr']['BTSPorts']){
				let sdr = {
					'id': enclosures[i]['id'],
					'name': enclosures[i]['name'],
					'bts': []
				}
				let protocolsObj = this._getProtocolsObj(enclosures[i]['sdr']['protocols']);

				for(let k=0; k<enclosures[i]['sdr']['BTSPorts'].length; k++){
					sdr.bts.push({
						'port': enclosures[i]['sdr']['BTSPorts'][k],
						'protocols': protocolsObj
					}); 
				}
				localBTS.push(sdr);
			}
		};
		console.log(localBTS);
		return localBTS;
	}
	// mapLocalBTS(enclosures) {
	// 	let localBTS = {};
	// 	for(let i=0; i<enclosures.length; i++){
	// 		if(enclosures[i]['sdr'] && enclosures[i]['sdr']['BTSPorts']){
	// 			localBTS[enclosures[i].id] = {};
	// 			let protocolsObj = this._getProtocolsObj(enclosures[i]['sdr']['protocols']);
	// 			for(let k=0; k<enclosures[i]['sdr']['BTSPorts'].length; k++){
	// 				localBTS[enclosures[i].id][enclosures[i]['sdr']['BTSPorts'][k]] = protocolsObj;
	// 			}
	// 		}
	// 	};
	// 	console.log(localBTS);
	// 	return localBTS;
	// }
	_getProtocolsObj(protocols: object) {
		// let protocolsObj = {
		// 	all: true
			// twoG: false,
			// threeG: false,
			// fourG: false
		// }; 
		for(let protocol in protocols){
			if(!protocol){
				protocols['all'] = false;
				return protocols;
			}
		// for(var i=0; i<protocols.length; i++){
			// protocols[i] === '2G' ? protocolsObj['twoG'] = true :
			// protocols[i] === '3G' ?  protocolsObj['threeG'] = true :
			// protocols[i] === '4G' ?  protocolsObj['fourG'] = true : false;
		}
		protocols['all'] = true;
		return protocols;
	}
	selectAllGsChanged(event){
		console.log(event);
	}

}
